def main():
  print("Hello learners!")

if __name__=="__main__":
  main()